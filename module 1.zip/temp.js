function f1(a){
	var elements = document.getElementsByClassName('nav-link');


Array.from(elements).forEach(child => {
    child.classList.remove('active')
});
	
a.classList.add('active')
}
